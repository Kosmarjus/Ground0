// let sum = 0;


// function sumatorius(a, b) {
//     sum = a + b;
//     console.log(sum);
// }

// sumatorius(+prompt('a'), +prompt('b'));



const MOCK_DATA = [{
    "country": "China",
    "first_name": "Jay",
    "last_name": "Clace",
    "age": 66,
    "gender": "Male",
    "status": false
}, {
    "country": "China",
    "first_name": "Janeva",
    "last_name": "Rae",
    "age": 22,
    "gender": "Female",
    "status": true
}, {
    "country": "Tunisia",
    "first_name": "Myles",
    "last_name": "Dirr",
    "age": 46,
    "gender": "Male",
    "status": true
}, {
    "country": "China",
    "first_name": "Jamison",
    "last_name": "Tough",
    "age": 24,
    "gender": "Male",
    "status": false
}, {
    "country": "Mauritius",
    "first_name": "Bonni",
    "last_name": "Beggi",
    "age": 60,
    "gender": "Female",
    "status": true
}, {
    "country": "Russia",
    "first_name": "Catherina",
    "last_name": "Massie",
    "age": 28,
    "gender": "Female",
    "status": false
}, {
    "country": "Afghanistan",
    "first_name": "Joellen",
    "last_name": "Hirsch",
    "age": 48,
    "gender": "Female",
    "status": true
}, {
    "country": "Russia",
    "first_name": "Forest",
    "last_name": "Bockler",
    "age": 77,
    "gender": "Male",
    "status": true
}, {
    "country": "Sweden",
    "first_name": "Trever",
    "last_name": "Reaveley",
    "age": 59,
    "gender": "Male",
    "status": true
}, {
    "country": "Argentina",
    "first_name": "Devin",
    "last_name": "Suggey",
    "age": 67,
    "gender": "Male",
    "status": false
}, {
    "country": "Brazil",
    "first_name": "Gabi",
    "last_name": "Saph",
    "age": 63,
    "gender": "Female",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Winnifred",
    "last_name": "Dearnaly",
    "age": 29,
    "gender": "Female",
    "status": true
}, {
    "country": "France",
    "first_name": "Hadrian",
    "last_name": "Mabbot",
    "age": 29,
    "gender": "Male",
    "status": true
}, {
    "country": "Philippines",
    "first_name": "Bernard",
    "last_name": "Brims",
    "age": 64,
    "gender": "Male",
    "status": false
}, {
    "country": "France",
    "first_name": "Katharyn",
    "last_name": "Gaisford",
    "age": 20,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Sioux",
    "last_name": "Labbe",
    "age": 70,
    "gender": "Female",
    "status": true
}, {
    "country": "Germany",
    "first_name": "Jillian",
    "last_name": "Snugg",
    "age": 40,
    "gender": "Female",
    "status": true
}, {
    "country": "China",
    "first_name": "Kimberly",
    "last_name": "Selburn",
    "age": 71,
    "gender": "Female",
    "status": true
}, {
    "country": "South Africa",
    "first_name": "Laetitia",
    "last_name": "Lent",
    "age": 36,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Gipsy",
    "last_name": "Ruffell",
    "age": 72,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Aurelea",
    "last_name": "Crosswaite",
    "age": 43,
    "gender": "Female",
    "status": true
}, {
    "country": "China",
    "first_name": "Jorie",
    "last_name": "Jerg",
    "age": 20,
    "gender": "Female",
    "status": true
}, {
    "country": "Madagascar",
    "first_name": "Ivar",
    "last_name": "Cockcroft",
    "age": 23,
    "gender": "Male",
    "status": false
}, {
    "country": "Albania",
    "first_name": "Desi",
    "last_name": "Peffer",
    "age": 45,
    "gender": "Male",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Daloris",
    "last_name": "Axelbey",
    "age": 26,
    "gender": "Female",
    "status": true
}, {
    "country": "France",
    "first_name": "Trenton",
    "last_name": "Gladyer",
    "age": 19,
    "gender": "Male",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Jonathon",
    "last_name": "Tethcote",
    "age": 51,
    "gender": "Male",
    "status": true
}, {
    "country": "Sri Lanka",
    "first_name": "Tiff",
    "last_name": "Pichmann",
    "age": 30,
    "gender": "Female",
    "status": false
}, {
    "country": "Ghana",
    "first_name": "Mattie",
    "last_name": "Cymper",
    "age": 31,
    "gender": "Male",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Chalmers",
    "last_name": "Crossfeld",
    "age": 58,
    "gender": "Male",
    "status": true
}, {
    "country": "Sweden",
    "first_name": "Cosette",
    "last_name": "Farbrace",
    "age": 39,
    "gender": "Female",
    "status": false
}, {
    "country": "Macedonia",
    "first_name": "Kev",
    "last_name": "Niesel",
    "age": 27,
    "gender": "Male",
    "status": false
}, {
    "country": "Poland",
    "first_name": "Abbott",
    "last_name": "Sallery",
    "age": 78,
    "gender": "Male",
    "status": true
}, {
    "country": "Vietnam",
    "first_name": "Rory",
    "last_name": "Pottinger",
    "age": 64,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Shelba",
    "last_name": "Truelove",
    "age": 46,
    "gender": "Female",
    "status": true
}, {
    "country": "China",
    "first_name": "Noelyn",
    "last_name": "Berrygun",
    "age": 32,
    "gender": "Female",
    "status": false
}, {
    "country": "Slovenia",
    "first_name": "Marlo",
    "last_name": "Mercer",
    "age": 19,
    "gender": "Female",
    "status": true
}, {
    "country": "Greece",
    "first_name": "Rhona",
    "last_name": "Corcut",
    "age": 42,
    "gender": "Female",
    "status": true
}, {
    "country": "Jordan",
    "first_name": "Kalila",
    "last_name": "Stadden",
    "age": 20,
    "gender": "Female",
    "status": true
}, {
    "country": "Sweden",
    "first_name": "Avery",
    "last_name": "Thomsson",
    "age": 27,
    "gender": "Male",
    "status": true
}, {
    "country": "France",
    "first_name": "Mildrid",
    "last_name": "Joyes",
    "age": 29,
    "gender": "Female",
    "status": true
}, {
    "country": "Indonesia",
    "first_name": "Anabel",
    "last_name": "Cantor",
    "age": 22,
    "gender": "Female",
    "status": false
}, {
    "country": "Nigeria",
    "first_name": "Cristionna",
    "last_name": "Tollemache",
    "age": 47,
    "gender": "Female",
    "status": true
}, {
    "country": "Argentina",
    "first_name": "Aland",
    "last_name": "Durtnell",
    "age": 76,
    "gender": "Male",
    "status": false
}, {
    "country": "Russia",
    "first_name": "Harry",
    "last_name": "Habbergham",
    "age": 38,
    "gender": "Male",
    "status": true
}, {
    "country": "Senegal",
    "first_name": "Ivory",
    "last_name": "Putnam",
    "age": 67,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Veriee",
    "last_name": "Dumpleton",
    "age": 79,
    "gender": "Female",
    "status": true
}, {
    "country": "Indonesia",
    "first_name": "Durand",
    "last_name": "Chisholm",
    "age": 41,
    "gender": "Male",
    "status": false
}, {
    "country": "Philippines",
    "first_name": "Kessiah",
    "last_name": "Tarbert",
    "age": 65,
    "gender": "Female",
    "status": true
}, {
    "country": "Poland",
    "first_name": "Ab",
    "last_name": "Hardeman",
    "age": 38,
    "gender": "Male",
    "status": false
}, {
    "country": "Brazil",
    "first_name": "Mill",
    "last_name": "Broadstock",
    "age": 22,
    "gender": "Male",
    "status": false
}, {
    "country": "Greece",
    "first_name": "Ramsay",
    "last_name": "Mechem",
    "age": 65,
    "gender": "Male",
    "status": false
}, {
    "country": "Portugal",
    "first_name": "Lucila",
    "last_name": "Brendel",
    "age": 57,
    "gender": "Female",
    "status": true
}, {
    "country": "France",
    "first_name": "Mabel",
    "last_name": "Bugg",
    "age": 44,
    "gender": "Female",
    "status": false
}, {
    "country": "North Korea",
    "first_name": "Val",
    "last_name": "Northgraves",
    "age": 46,
    "gender": "Female",
    "status": false
}, {
    "country": "Ukraine",
    "first_name": "Annice",
    "last_name": "Broek",
    "age": 64,
    "gender": "Female",
    "status": true
}, {
    "country": "Democratic Republic of the Congo",
    "first_name": "Arney",
    "last_name": "Anstiss",
    "age": 47,
    "gender": "Male",
    "status": true
}, {
    "country": "Palestinian Territory",
    "first_name": "Carey",
    "last_name": "Beany",
    "age": 55,
    "gender": "Male",
    "status": false
}, {
    "country": "China",
    "first_name": "Steffi",
    "last_name": "Scrivens",
    "age": 71,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Burty",
    "last_name": "Blaskett",
    "age": 48,
    "gender": "Male",
    "status": true
}, {
    "country": "Cuba",
    "first_name": "Flss",
    "last_name": "Walkington",
    "age": 31,
    "gender": "Female",
    "status": true
}, {
    "country": "Russia",
    "first_name": "Ewart",
    "last_name": "Puvia",
    "age": 46,
    "gender": "Male",
    "status": true
}, {
    "country": "Russia",
    "first_name": "Gerhardt",
    "last_name": "Barnsdall",
    "age": 42,
    "gender": "Male",
    "status": false
}, {
    "country": "Thailand",
    "first_name": "Karylin",
    "last_name": "Perkin",
    "age": 41,
    "gender": "Female",
    "status": false
}, {
    "country": "Israel",
    "first_name": "Marlon",
    "last_name": "Legon",
    "age": 78,
    "gender": "Male",
    "status": true
}, {
    "country": "China",
    "first_name": "Gabie",
    "last_name": "Skeffington",
    "age": 52,
    "gender": "Male",
    "status": false
}, {
    "country": "Ethiopia",
    "first_name": "Bekki",
    "last_name": "Frenchum",
    "age": 46,
    "gender": "Female",
    "status": true
}, {
    "country": "Indonesia",
    "first_name": "Bernardina",
    "last_name": "Dowson",
    "age": 27,
    "gender": "Female",
    "status": true
}, {
    "country": "Kenya",
    "first_name": "Maegan",
    "last_name": "Belleny",
    "age": 19,
    "gender": "Female",
    "status": true
}, {
    "country": "Japan",
    "first_name": "Bryant",
    "last_name": "Escoffier",
    "age": 65,
    "gender": "Male",
    "status": true
}, {
    "country": "Indonesia",
    "first_name": "Artie",
    "last_name": "Swinglehurst",
    "age": 32,
    "gender": "Male",
    "status": true
}, {
    "country": "Japan",
    "first_name": "Catherine",
    "last_name": "Woolmington",
    "age": 60,
    "gender": "Female",
    "status": false
}, {
    "country": "Poland",
    "first_name": "Brittni",
    "last_name": "Shillan",
    "age": 53,
    "gender": "Female",
    "status": true
}, {
    "country": "France",
    "first_name": "Mannie",
    "last_name": "Highman",
    "age": 27,
    "gender": "Male",
    "status": false
}, {
    "country": "Russia",
    "first_name": "Dani",
    "last_name": "Ivanenko",
    "age": 65,
    "gender": "Male",
    "status": false
}, {
    "country": "China",
    "first_name": "Astrix",
    "last_name": "Roake",
    "age": 51,
    "gender": "Female",
    "status": false
}, {
    "country": "France",
    "first_name": "Ella",
    "last_name": "Howgill",
    "age": 32,
    "gender": "Female",
    "status": false
}, {
    "country": "China",
    "first_name": "Reade",
    "last_name": "Nicholls",
    "age": 23,
    "gender": "Male",
    "status": true
}, {
    "country": "Russia",
    "first_name": "Odette",
    "last_name": "Christene",
    "age": 23,
    "gender": "Female",
    "status": true
}, {
    "country": "China",
    "first_name": "Jemmie",
    "last_name": "Will",
    "age": 57,
    "gender": "Female",
    "status": true
}, {
    "country": "Jordan",
    "first_name": "Bobbee",
    "last_name": "McGrudder",
    "age": 55,
    "gender": "Female",
    "status": true
}, {
    "country": "Colombia",
    "first_name": "Reynolds",
    "last_name": "Helkin",
    "age": 55,
    "gender": "Male",
    "status": false
}, {
    "country": "Philippines",
    "first_name": "Winnie",
    "last_name": "McCullogh",
    "age": 40,
    "gender": "Male",
    "status": false
}, {
    "country": "Jamaica",
    "first_name": "Nicoline",
    "last_name": "Maides",
    "age": 18,
    "gender": "Female",
    "status": true
}, {
    "country": "Bangladesh",
    "first_name": "Brynn",
    "last_name": "Matous",
    "age": 40,
    "gender": "Female",
    "status": false
}, {
    "country": "Serbia",
    "first_name": "Nara",
    "last_name": "Berridge",
    "age": 29,
    "gender": "Female",
    "status": true
}, {
    "country": "Sweden",
    "first_name": "Natalina",
    "last_name": "MacGarvey",
    "age": 34,
    "gender": "Female",
    "status": true
}, {
    "country": "Mongolia",
    "first_name": "Marsiella",
    "last_name": "Scougal",
    "age": 52,
    "gender": "Female",
    "status": true
}, {
    "country": "France",
    "first_name": "Lombard",
    "last_name": "Choppin",
    "age": 48,
    "gender": "Male",
    "status": false
}, {
    "country": "Ukraine",
    "first_name": "Ulrika",
    "last_name": "Netherclift",
    "age": 38,
    "gender": "Female",
    "status": false
}, {
    "country": "United States",
    "first_name": "Yard",
    "last_name": "Larne",
    "age": 31,
    "gender": "Male",
    "status": true
}, {
    "country": "Vietnam",
    "first_name": "Tait",
    "last_name": "Gepp",
    "age": 35,
    "gender": "Male",
    "status": false
}, {
    "country": "United States",
    "first_name": "Arney",
    "last_name": "Crawley",
    "age": 40,
    "gender": "Male",
    "status": false
}, {
    "country": "Poland",
    "first_name": "Verna",
    "last_name": "Prester",
    "age": 46,
    "gender": "Female",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Alden",
    "last_name": "Maceur",
    "age": 19,
    "gender": "Male",
    "status": true
}, {
    "country": "Ukraine",
    "first_name": "Eada",
    "last_name": "Benmore",
    "age": 77,
    "gender": "Female",
    "status": false
}, {
    "country": "France",
    "first_name": "Rosabel",
    "last_name": "Johnys",
    "age": 55,
    "gender": "Female",
    "status": false
}, {
    "country": "Indonesia",
    "first_name": "Carie",
    "last_name": "Ablitt",
    "age": 38,
    "gender": "Female",
    "status": false
}, {
    "country": "Haiti",
    "first_name": "Gearalt",
    "last_name": "Plowes",
    "age": 29,
    "gender": "Male",
    "status": false
}, {
    "country": "France",
    "first_name": "Hoebart",
    "last_name": "Pheby",
    "age": 73,
    "gender": "Male",
    "status": true
}]



//   Sukurkite funkcijas, kurios grąžintų:
//   - šalių sąrašą <array>
//   - vidutinį žmonių amžių <number>
//   - tik žmones, kurie aktyvūs <array> [{



var countryList = [];
var uniqueCountries = [];

function createCountryList(arr) {
    for (let i = 0; i < arr.length; i++) {
        countryList.push(arr[i]["country"]);
    }
}

function removeDuplicates(arr) {
    for (let i = 0; i < arr.length; i++) {
        if (uniqueCountries.indexOf(arr[i]) == -1) {
            uniqueCountries.push(arr[i])
        }
    }
    return uniqueCountries
}

createCountryList(MOCK_DATA);
removeDuplicates(countryList);


uniqueCountries.sort();
console.log(uniqueCountries);


function calculateAverageAge(arr) {
    var averageAge = 0;
    let totalAge = 0;
    for (let i = 0; i < arr.length; i++) {
        totalAge = totalAge + (arr[i]["age"]);
    }
    averageAge = totalAge / arr.length;
    console.log(averageAge);
}

// calculateAverageAge(MOCK_DATA.filter(function(obj){
//     return obj.country === "France";
// }));
calculateAverageAge(MOCK_DATA);

var activeList = [];

function listActiveOnly(arr) {

    for (let i = 0; i < arr.length; i++) {
        if (arr[i]["status"])
            activeList.push(arr[i]["first_name"]+' '+ arr[i]["last_name"]);
    }
}

listActiveOnly(MOCK_DATA);
console.log(activeList);



//random

function randomPerson(arr) {
    var randomNumber = Math.floor(Math.random() * arr.length);
    // console.log(randomNumber);
    console.log(arr[randomNumber]['first_name'] +' ' +arr[randomNumber]['last_name'] );
}
randomPerson(MOCK_DATA);



// for (item of Object.values(uniq)) {
//     console.log(item)
// }


//new

// function getAverageAge(test) {
//     for (const person of test) {
//         console.log(person.age)
//     }
// }

// getAverageAge(MOCK_DATA);





// MOCK_DATA.forEach(function(element, ) {
//     console.log(element);
// });