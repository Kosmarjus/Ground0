let button = document.querySelector('.button');
let input = document.querySelector('.input');
var counter = 0;
button.addEventListener('click', function () {
    createNewTask(input.value);
});

function createNewTask(input) {
    counter++;
    let createLi = document.createElement('li');
    createLi.className = 'input' + counter;
    let textInput = document.createTextNode(input);
    createLi.appendChild(textInput);
    document.getElementById('tasks').appendChild(createLi);
    let removeButton = document.createElement('button');
    removeButton.innerText = 'remove';
    removeButton.addEventListener("click", function () {
        createLi.remove();
    })

    createLi.appendChild(removeButton);
}